from django.contrib import admin
from .models import Payroll, Base_payroll
# Register your models here.

admin.site.register(Payroll)
admin.site.register(Base_payroll)
