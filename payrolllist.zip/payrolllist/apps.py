from django.apps import AppConfig


class PayrolllistConfig(AppConfig):
    name = 'payrolllist'
